package com.bit.exception;


public class ParameterException extends RuntimeException {
    private String code;

    public ParameterException() {
    }

    public ParameterException(String message) {
        super("客户端异常"+message);
    }

    public ParameterException(String message, Throwable cause) {
        super("客户端异常"+message, cause);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
