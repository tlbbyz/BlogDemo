package com.bit.util;


import com.bit.exception.SystemException;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DButil {
    private DButil() {}

    private static final String URL = "jdbc:mysql://localhost:3306/blogdemo";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "150300";
    private static volatile DataSource DATASOURCE;

    public static DataSource getDATASOURCE() {
            synchronized (DButil.class) {
                //多线程时JVM会对代码进行指令重排。
                if (DATASOURCE == null) {
                    DATASOURCE = new MysqlDataSource();
                    ((MysqlDataSource) DATASOURCE).setURL(URL);
                    ((MysqlDataSource) DATASOURCE).setUser(USERNAME);
                    ((MysqlDataSource) DATASOURCE).setPassword(PASSWORD);
                }
        }
        return DATASOURCE;
    }

    public static Connection getConnection() {
        try {
            return getDATASOURCE().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public  static void close(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        if(resultSet!=null){
            try {
                resultSet.close();
                if(preparedStatement!=null){
                    preparedStatement.close();
                }
                if(connection!=null){
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SystemException("数据库错误");
            }
        }
    }
}