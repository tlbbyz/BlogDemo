package com.bit.servlet;


import com.bit.exception.BusinessException;
import com.bit.exception.ParameterException;
import com.bit.util.DButil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;


@WebServlet("/articleDelete")
public class ArticleDeleteServlet extends BaseServlet {
    @Override
    public Object process(HttpServletRequest req, HttpServletResponse resp) throws Exception {

        String ids = req.getParameter("ids");
        int[] idArray;
        String[] strings;
        try {
            strings = ids.split(",");
            idArray = new int[strings.length];
            for (int i = 0; i < strings.length; i++) {
                idArray[i] = Integer.parseInt(strings[i]);
            }
        } catch (Exception e) {
            throw new ParameterException("请求参数错误ids=" + ids);
        }
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = DButil.getConnection();
            StringBuilder sql = new StringBuilder("delete from article where id in (");
            for (int i = 0; i < idArray.length; i++) {
                if(i==0){
                    sql.append("?");
                }else {
                    sql.append(",?");
                }
            }
            sql.append(")");
            System.out.println(sql);
            preparedStatement = connection.prepareStatement(sql.toString());
            for (int i = 0; i < idArray.length; i++) {
                preparedStatement.setInt(i+1,idArray[i]);
            }
            int r = preparedStatement.executeUpdate();
            if (r > 0) {
                return r;
            } else {
                throw new BusinessException("删除失败");
            }
        } finally {
            DButil.close(connection, preparedStatement, null);
        }
    }
}
