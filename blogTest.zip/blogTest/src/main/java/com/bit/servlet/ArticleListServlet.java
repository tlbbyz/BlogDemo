package com.bit.servlet;

import com.bit.entity.Article;
import com.bit.exception.ParameterException;
import com.bit.util.DButil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ArticleListServlet extends BaseServlet {
    @Override
    public Object process(HttpServletRequest req, HttpServletResponse resp) {
        Connection connection = null;
        PreparedStatement preparedStatement= null;
        ResultSet resultSet = null;
        List<Article> list = new ArrayList<>();
        String sid = req.getParameter("id");
        try {
            Integer id = Integer.parseInt(sid);
        }catch (NumberFormatException e){
            throw new ParameterException("id错误("+sid+")");
        }
        try {
            connection = DButil.getConnection();
            String sql = "select a.id,a.title,a.content,a.create_time from article a  join user u on a.user_id=u.id " +
                    "where u.id=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,Integer.parseInt(req.getParameter("id")));
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Article article = new Article();
                article.setId(resultSet.getInt("id"));
                article.setTitle(resultSet.getString("title"));
                article.setContent(resultSet.getString("content"));
                article.setCreateTime(resultSet.getTimestamp("create_time"));
                list.add(article);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(resultSet!=null){
                    resultSet.close();
                }
                if(preparedStatement!=null){
                    preparedStatement.close();
                }
                if(connection!=null){
                    connection.close();
                }
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return  list;
    }
}
