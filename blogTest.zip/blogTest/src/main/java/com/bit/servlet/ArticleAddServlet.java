package com.bit.servlet;

import com.bit.entity.Article;
import com.bit.exception.BusinessException;
import com.bit.util.DButil;
import com.bit.util.JSONUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class ArticleAddServlet extends BaseServlet {

    @Override
    public Object process(HttpServletRequest req, HttpServletResponse resp) throws Exception{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        //application/json数据需要inputStream获取
        Article article = JSONUtil.get(req,Article.class);
        try {
            connection = DButil.getConnection();
            String sql = "insert into article(title, content, create_time, user_id) " +
                    "select ?,?,now(),user.id from user " +
                    "where user.name=?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, article.getTitle());
            preparedStatement.setString(2, article.getContent());
            preparedStatement.setString(3, article.getUserAccout());
            int r = preparedStatement.executeUpdate();
            if (r > 0) {
                return r;
            } else {
                throw new BusinessException("没有该用户" + article.getUserAccout());
            }
        }finally {
            DButil.close(connection, preparedStatement, null);
        }
    }
}